#Question 1

# 1.binomial distribution
# 2
pbinom(46,50,0.85,lower.tail = FALSE)
# lower.trail = false means X>p
# lower.trail = true means X<=p

#Question 2

# 1. Random variable X - number of receiving calls per hour
# 2. Poisson distribution
# 3.
dpois(15,12)